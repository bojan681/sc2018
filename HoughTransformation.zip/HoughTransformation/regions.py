import cv2
import numpy as np
import matplotlib.pyplot as plt
import NeuralNetworkPredict as pred

plt.ion()

def resize_region(region):
    '''Transformisati selektovani region na sliku dimenzija 28x28'''
    return cv2.resize(region,(20,20), interpolation = cv2.INTER_NEAREST)


def select_roi(image):
    siva = cv2.cvtColor(image.copy(), cv2.COLOR_BGR2GRAY)
    zamucena = cv2.GaussianBlur(siva, (5, 5), 0)
    threshold = cv2.threshold(zamucena, 60, 255, cv2.THRESH_BINARY)[1]

    img, contours, hierarchy = cv2.findContours(
        threshold.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    objects = []

    for c in contours:

        (x, y), radius = cv2.minEnclosingCircle(c)
        center = (int(x), int(y))
        x=int(x)
        y=int(y)
        radius = int(radius)
        if radius < 20 and radius>7:
                object.append(center,radius)
    return objects

def predict(region):
    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
    scale = scale_to_range(gray)
    resized = resize_region(scale)
    img = cv2.copyMakeBorder(
        resized, 4, 4, 4, 4, cv2.BORDER_CONSTANT, value=[0, 0, 0])
    cv2.imshow('region', img)
    cv2.waitKey(100000)
    print(pred.predict(img))


def scale_to_range(image): # skalira elemente slike na opseg od 0 do 1
    ''' Elementi matrice image su vrednosti 0 ili 255.
        Potrebno je skalirati sve elemente matrica na opseg od 0 do 1
    '''
    return image/255


def image_bin(image_gs):
    height, width = image_gs.shape[0:2]
    image_binary = np.ndarray((height, width), dtype=np.uint8)
    ret,image_bin = cv2.threshold(image_binary, 127, 255, cv2.THRESH_BINARY)
    return image_bin


def invert(image):
    return 255-image


def dilate(image):
    kernel = np.ones((3,3)) # strukturni element 3x3 blok
    return cv2.dilate(image, kernel, iterations=1)


def erode(image):
    kernel = np.ones((3,3)) # strukturni element 3x3 blok
    return cv2.erode(image, kernel, iterations=1)

def display_image(image, color= False):
    if color:
        plt.imshow(image)
    else:
        plt.imshow(image, 'gray')