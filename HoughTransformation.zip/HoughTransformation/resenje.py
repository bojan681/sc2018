import sys
import Calman

file = open('out.txt','w')
file.write("RA/249/2016 Bojan Jankovic")
file.write('\nfile  sum')

for i in range(0,10):
    r = Calman.resenje("videos/video-" + str(i) + ".avi")
    file.write("\nvideo-"+ str(i) + ".avi\t" + str(r))
