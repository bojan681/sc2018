import cv2
import numpy as np

n=10000

def get_green(firstFrame1):
    firstFrame = firstFrame1.copy()
    firstFrame[:, :, 0] = 0
    gray = cv2.cvtColor(firstFrame, cv2.COLOR_BGR2GRAY)
    ret, t = cv2.threshold(gray, 25, 255, cv2.THRESH_BINARY)
    minLineLength = 100
    maxLineGap = 10
    lines = cv2.HoughLinesP(t, 1, np.pi / 180, 100, minLineLength, maxLineGap)
    x_1 = min(lines[:, 0, 0])
    y_1 = max(lines[:, 0, 1])
    x_2 = max(lines[:, 0, 2])
    y_2 = min(lines[:, 0, 3])
    return [(x_1, y_1), (x_2, y_2)]

def get_blue(firstFrame1):
    firstFrame = firstFrame1.copy()
    firstFrame[:, :, 1] = 0
    gray = cv2.cvtColor(firstFrame, cv2.COLOR_BGR2GRAY)
    ret, t = cv2.threshold(gray, 25, 255, cv2.THRESH_BINARY)
    minLineLength = 100
    maxLineGap = 10
    lines = cv2.HoughLinesP(t, 1, np.pi / 180, 100, minLineLength, maxLineGap)
    x_1 = min(lines[:, 0, 0])
    y_1 = max(lines[:, 0, 1])
    x_2 = max(lines[:, 0, 2])
    y_2 = min(lines[:, 0, 3])
    return [(x_1, y_1), (x_2, y_2)]
